package com.example.EverBank.view

import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.support.annotation.RequiresApi
import android.support.v7.app.AppCompatActivity
import android.view.Menu
import android.view.View
import android.widget.Toast
import com.example.EverBank.utils.User
import com.example.EverBank.utils.Utils
import com.example.poceveris_beacon.R
import com.google.firebase.FirebaseApp
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.FirebaseDatabase
import kotlinx.android.synthetic.main.activity_cadastro.*

@RequiresApi(Build.VERSION_CODES.O)
class CadastroActivity : AppCompatActivity() {

    private var firebaseDatabase: FirebaseDatabase? = FirebaseDatabase.getInstance()
    private var databaseReference: DatabaseReference? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_cadastro)
        FirebaseApp.initializeApp(this@CadastroActivity)
        databaseReference = firebaseDatabase!!.reference
    }


    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        val inflater = menuInflater
        inflater.inflate(R.menu.menu_formulario, menu)
        return super.onCreateOptionsMenu(menu)
    }


    fun onClick(view: View) {

        val campoNome: String = ed_loginCadastro.text.toString()
        val campoEmail: String = ed_emailCadastro.text.toString()
        val campoSenha: String = ed_senhaCadastro.text.toString()
        val confimSenha: String = ed_confirmsenha.text.toString()

        btn_cadastro.setOnClickListener {

            val usuario = User()
            usuario.id = Utils.encoderBase64(campoEmail)
            usuario.login = campoNome
            usuario.email = campoEmail
            usuario.senha = Utils.encoderBase64(campoSenha).replace("\n", "")
            usuario.cfsenha = Utils.encoderBase64(confimSenha).replace("\n", "")
            databaseReference!!.child("Usuarios").child(usuario.id.toString().replace("\n", "")).setValue(usuario)

            Toast.makeText(this, "Usuario :" + usuario.login.toString() + ", Adicionado", Toast.LENGTH_SHORT).show()
            goLogin()

        }
    }

    fun goLogin() {
        val intent = Intent(applicationContext, LoginActivity::class.java)
        startActivity(intent)
    }
}
