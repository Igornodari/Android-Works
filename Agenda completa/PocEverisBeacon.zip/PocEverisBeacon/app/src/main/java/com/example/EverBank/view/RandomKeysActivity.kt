package com.example.EverBank.view

import android.os.Bundle
import android.support.v7.app.AppCompatActivity


class RandomKeysActivity : AppCompatActivity() {

    private var position: Int? = null
    private var positionExtra: Int? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        position = getExtra()
        init(this, position!!)
    }

    private fun getExtra(): Int? {
        val extras = intent.extras
        if (extras != null) {
            positionExtra = extras.getInt("position")
        }
        return positionExtra
    }

    fun init(activity: AppCompatActivity, position: Int) {

        var contadorSaque: Int


        when (position) {

            0 -> {

            }

            1 -> {

            }

//            2 -> {
//                activity.layoutInflater.inflate(R.layout.card_senha_gerente, null)
//                var textView: TextView? = activity.findViewById(R.id.tv_physenha)
//                textView!!.text = "PHY" + myRandom.nextInt(100)
//            }
//            3 -> {
//                activity.layoutInflater.inflate(R.layout.card_senha_gerente, null)
//                var textView: TextView? = activity.findViewById(R.id.tv_physenha)
//                textView!!.text = "PHY" + myRandom.nextInt(100)
//            }
//            4 -> {
//                activity.layoutInflater.inflate(R.layout.card_senha_gerente, null)
//                var textView: TextView? = activity.findViewById(R.id.tv_physenha)
//                textView!!.text = "PHY" + myRandom.nextInt(100)
//            }
//            5 -> {
//                activity.layoutInflater.inflate(R.layout.card_senha_gerente, null)
//                var textView: TextView? = activity.findViewById(R.id.tv_physenha)
//                textView!!.text = "PHY" + myRandom.nextInt(100)
//            }

        }
    }

}

