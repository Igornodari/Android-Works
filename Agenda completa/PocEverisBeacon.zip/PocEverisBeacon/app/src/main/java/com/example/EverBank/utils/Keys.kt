package com.example.EverBank.utils

class Keys(var numShards: Int)
class Shard(var count: Int)
