package com.example.EverBank.utils

class User {

    var id: String? = null
    var login: String? = null
    var email: String? = null
    var senha: String? = null
    var cfsenha: String? = null

}