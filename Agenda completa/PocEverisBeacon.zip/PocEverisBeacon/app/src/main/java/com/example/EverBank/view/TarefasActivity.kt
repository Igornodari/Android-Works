package com.example.EverBank.view

import android.bluetooth.BluetoothAdapter
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.support.v7.app.AppCompatActivity
import android.support.v7.widget.GridLayoutManager
import android.support.v7.widget.RecyclerView
import android.util.Log
import android.view.View
import com.example.EverBank.service.BluetoothReceiver
import com.example.EverBank.utils.RecyclerItemClickListenr
import com.example.EverBank.utils.Tarefas
import com.example.EverBank.utils.Utils
import com.example.poceveris_beacon.R.*
import java.util.*


class TarefasActivity : AppCompatActivity() {

    private var beaconMonitoring: Intent? = null
    private var isServiceStopped: Boolean = false
    private var bluetoothReceiver: BluetoothReceiver? = null
    lateinit var listView: RecyclerView
    lateinit var context: Context
    private lateinit var adapter: MyListAdapter
    internal var TAG = TarefasActivity::class.java.simpleName

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(layout.activity_tarefas)

        try {
            bluetoothReceiver = BluetoothReceiver()
            context = this
            listView = findViewById(id.rv_tarefas)
            listView.layoutManager = GridLayoutManager(this, 2, GridLayoutManager.HORIZONTAL, false)

            val versionList = listPopulate()
            adapter = MyListAdapter(versionList)
            listView.adapter = adapter

            listView.addOnItemTouchListener(
                RecyclerItemClickListenr(
                    this,
                    listView,
                    object : RecyclerItemClickListenr.OnItemClickListener {
                        override fun onItemClick(view: View, position: Int) {

                            when (position) {
                                0 -> {
                                    nextAct(position)
                                }
                                1 -> nextAct(position)
                                2 -> nextAct(position)
                                3 -> nextAct(position)
                                4 -> nextAct(position)
                                5 -> nextAct(position)
                            }
                        }

                        override fun onItemLongClick(view: View?, position: Int) {
                            TODO("not implemented") //To change body of created functions use File | Settings | File Templates.
                        }
                    })
            )

        } catch (e: Exception) {
            Log.e(TAG, e.message)
        }

        if (getBluetoothState()) {
            setBluetooth(enable = false)
            bluetoothReceiver!!.stopService(this, Utils.getBlueToothState())
        }


    }

    private fun listPopulate(): ArrayList<Tarefas> {
        val versionList = ArrayList<Tarefas>()
        versionList.add(Tarefas(drawable.iconos_cs5_10, "Saque"))
        versionList.add(Tarefas(drawable.iconos_cs5_16, "Deposito"))
        versionList.add(Tarefas(drawable.iconos_cs5_125, "Pagar Contas"))
        versionList.add(Tarefas(drawable.iconos_cs5_40_2, "Falar com Gerente"))
        versionList.add(Tarefas(drawable.iconos_cs5_51, "Informações"))
        versionList.add(Tarefas(drawable.iconos_cs5_40, "Outros"))

        return versionList
    }

    fun setBluetooth(enable: Boolean): Boolean {

        val bluetoothAdapter = BluetoothAdapter.getDefaultAdapter()
        val isEnabled = bluetoothAdapter.isEnabled

        if (enable && !isEnabled) {
            return bluetoothAdapter.enable()
        } else if (!enable && isEnabled) {
            return bluetoothAdapter.disable()
        }
        return true
    }

    fun getBluetoothState(): Boolean {
        val bluetoothAdapter = BluetoothAdapter.getDefaultAdapter()
        Utils.setBlueToothState(BluetoothAdapter.getDefaultAdapter().state)
        return bluetoothAdapter.isEnabled
    }

    fun nextAct(position: Int) {
        intent = Intent(this, RandomKeysActivity::class.java)
        intent.putExtra("position", position)
        startActivity(intent)
    }

}
