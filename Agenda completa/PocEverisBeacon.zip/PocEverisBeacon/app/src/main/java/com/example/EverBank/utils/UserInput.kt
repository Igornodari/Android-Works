package com.example.EverBank.utils

class UserInput(login: String, pass: String) {
    var login: String? = login
    var password: String? = pass
}
