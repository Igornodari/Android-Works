package com.example.EverBank.utils

import com.example.poceveris_beacon.R
import java.util.*

class Tarefas(val url: Int, val name: String) {

    fun listPopulate(): ArrayList<Tarefas> {
        val versionList = ArrayList<Tarefas>()
        versionList.add(Tarefas(R.drawable.iconos_cs5_10, "Saque"))
        versionList.add(Tarefas(R.drawable.iconos_cs5_16, "Deposito"))
        versionList.add(Tarefas(R.drawable.iconos_cs5_125, "Pagar Contas"))
        versionList.add(Tarefas(R.drawable.iconos_cs5_40_2, "Falar com Gerente"))
        versionList.add(Tarefas(R.drawable.iconos_cs5_40, "Outros"))
        return versionList
    }

}